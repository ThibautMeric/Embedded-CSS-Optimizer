from Embedded_CSS_Optimizer.Step3.GenerateCss import *

def IsDotMin(Version, CssTable):
    GenerateCss(1, Version, CssTable)
pass
