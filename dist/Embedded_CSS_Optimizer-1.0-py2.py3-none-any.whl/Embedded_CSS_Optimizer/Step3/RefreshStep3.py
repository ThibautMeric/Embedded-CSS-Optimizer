def RefreshStep3(lfStep3):

    lfStep3.children["generate"].grid(row=0, column=0, pady="30")
    lfStep3.children["generatedotmin"].grid(row=1, column=0, pady="30")
    lfStep3.children["reset"].grid(row=2, column=0, pady="30")
    lfStep3.grid(row=1, column=3, sticky="n s")

pass
