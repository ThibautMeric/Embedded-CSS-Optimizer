from Embedded_CSS_Optimizer.Step3.GenerateCss import *

def IsClassic(Version, CssTable):
    GenerateCss(0, Version, CssTable)
pass
