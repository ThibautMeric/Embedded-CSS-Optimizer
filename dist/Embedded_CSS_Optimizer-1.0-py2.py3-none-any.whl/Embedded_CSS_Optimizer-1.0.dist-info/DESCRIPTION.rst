The main objective of this program is to lighten CSS files. This program will read your HTML files and your CSS files. Then, it will remove all definitions unused in the CSS file. Thanks to the GUI, you can customize this selection the way you prefer.


